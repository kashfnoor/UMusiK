#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QStringListModel>
#include "playlistmanager.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void createPlaylist();
    void deletePlaylist();
    void addSong();
    void removeSong();
    void playPauseSong();
    void playSong();
    void updatePlaylists();
    void updateSongs();
    void onSongEnded();
    void on_volumeSlider_valueChanged(int value);

    void on_positionSlider_valueChanged(int value);

    void on_positionChanged(qint64 position);

    void on_durationChanged(qint64 duration);

    void on_previousButton_clicked(); // Slot for previous button
    void on_nextButton_clicked();

private:
    Ui::MainWindow *ui;

    QMediaPlayer *player;
    QAudioOutput *audioOutput;
    PlaylistManager *playlistManager;
    bool isPlaying;
};
#endif // MAINWINDOW_H
